import os

# Set the environment variable to disable oneDNN optimizations
os.environ["TF_ENABLE_ONEDNN_OPTS"] = "0"

# Now import TensorFlow
import tensorflow as tf

# Your TensorFlow code here
