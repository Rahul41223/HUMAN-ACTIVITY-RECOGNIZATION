import numpy as np
from tensorflow.keras.utils import to_categorical
import cv2
import os

def load_video_frames(folder_path):
    frames = []
    for i in sorted(os.listdir(folder_path))[:40]:
        img = cv2.imread(os.path.join(folder_path, i))
        img = img.astype(np.float32) / 255.0
        frames.append(img)
    return np.array(frames)

def prepare_dataset(base_path, classes):
    X, y = [], []
    for label, cls in enumerate(classes):
        cls_path = os.path.join(base_path, cls)
        for video_folder in os.listdir(cls_path):
            video_path = os.path.join(cls_path, video_folder)
            frames = load_video_frames(video_path)
            if frames.shape[0] == 40:
                X.append(frames)
                y.append(label)
    return np.array(X), to_categorical(np.array(y), num_classes=len(classes))
