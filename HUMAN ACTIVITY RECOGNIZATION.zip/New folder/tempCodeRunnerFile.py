import numpy as np
from tensorflow.keras.utils import to_categorical
import cv2
import os

def load_video_frames(folder_path, num_frames=40, frame_size=(224, 224)):
    frames = []
    files = sorted(os.listdir(folder_path))[:num_frames]
    for file in files:
        img_path = os.path.join(folder_path, file)
        img = cv2.imread(img_path)
        if img is None:
            print(f"Warning: Could not read {img_path}")
            continue
        img = cv2.resize(img, frame_size)
        img = img.astype(np.float32) / 255.0
        frames.append(img)
    
    if len(frames) != num_frames:
        print(f"Warning: {folder_path} has only {len(frames)} valid frames (expected {num_frames}).")
    
    return np.array(frames)

def prepare_dataset(base_path, classes, num_frames=40):
    X, y = [], []
    for label, cls in enumerate(classes):
        cls_path = os.path.join(base_path, cls)
        if not os.path.isdir(cls_path):
            print(f"Skipping {cls_path}: Not a directory.")
            continue
        for video_folder in os.listdir(cls_path):
            video_path = os.path.join(cls_path, video_folder)
            if not os.path.isdir(video_path):
                continue
            frames = load_video_frames(video_path, num_frames=num_frames)
            if frames.shape[0] == num_frames:
                X.append(frames)
                y.append(label)
    X = np.array(X)
    y = to_categorical(np.array(y), num_classes=len(classes))
    print(f"Dataset loaded: {X.shape[0]} samples with shape {X.shape[1:]}")
    return X, y
