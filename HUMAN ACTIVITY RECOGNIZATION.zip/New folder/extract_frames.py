import cv2
import os

def extract_frames(video_path, save_dir, max_frames=40):
    cap = cv2.VideoCapture(video_path)
    frame_count = 0
    success, frame = cap.read()
    while success and frame_count < max_frames:
        frame = cv2.resize(frame, (224, 224))
        cv2.imwrite(f"{save_dir}/frame{frame_count:03d}.jpg", frame)
        frame_count += 1
        success, frame = cap.read()
    cap.release()
