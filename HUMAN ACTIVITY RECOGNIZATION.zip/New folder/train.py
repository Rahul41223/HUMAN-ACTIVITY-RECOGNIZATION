from preprocess import prepare_dataset
from model import build_model
from sklearn.model_selection import train_test_split

# Define class names (subset from UCF101 or your own)
classes = ['Walking', 'Running', 'Jumping']

# Load dataset
X, y = prepare_dataset("data", classes)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

# Build and train model
model = build_model(num_classes=len(classes))
model.fit(X_train, y_train, epochs=10, batch_size=4, validation_data=(X_test, y_test))
model.save("har_model.h5")
