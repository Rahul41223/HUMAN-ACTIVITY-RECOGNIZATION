from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import TimeDistributed, Conv2D, MaxPooling2D, Flatten, LSTM, Dense

def build_model(num_classes):
    model = Sequential([
        TimeDistributed(Conv2D(32, (3,3), activation='relu'), input_shape=(40, 224, 224, 3)),
        TimeDistributed(MaxPooling2D((2,2))),
        TimeDistributed(Conv2D(64, (3,3), activation='relu')),
        TimeDistributed(MaxPooling2D((2,2))),
        TimeDistributed(Flatten()),
        LSTM(64),
        Dense(64, activation='relu'),
        Dense(num_classes, activation='softmax')
    ])
    model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
    return model
