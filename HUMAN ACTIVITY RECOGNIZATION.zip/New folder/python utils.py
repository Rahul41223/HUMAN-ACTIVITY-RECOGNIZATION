import os
import cv2
import matplotlib.pyplot as plt
import numpy as np

def create_dir(path):
    """Creates directory if it doesn't exist."""
    if not os.path.exists(path):
        os.makedirs(path)

def extract_and_save_frames(video_path, save_dir, max_frames=40):
    """Extracts frames from a video and saves them to a directory."""
    create_dir(save_dir)
    cap = cv2.VideoCapture(video_path)
    count = 0
    success, frame = cap.read()
    while success and count < max_frames:
        frame = cv2.resize(frame, (224, 224))
        cv2.imwrite(f"{save_dir}/frame{count:03d}.jpg", frame)
        count += 1
        success, frame = cap.read()
    cap.release()

def display_video_frames(frames, num_to_display=5):
    """Displays a few frames from the video."""
    plt.figure(figsize=(15, 5))
    for i in range(num_to_display):
        plt.subplot(1, num_to_display, i+1)
        plt.imshow(frames[i])
        plt.axis('off')
    plt.show()

def count_videos_per_class(base_path):
    """Counts number of video folders per class."""
    class_counts = {}
    for class_name in os.listdir(base_path):
        class_path = os.path.join(base_path, class_name)
        if os.path.isdir(class_path):
            class_counts[class_name] = len(os.listdir(class_path))
    return class_counts

def normalize_frames(frames):
    """Normalizes a sequence of frames to [0, 1]."""
    return np.array(frames, dtype=np.float32) / 255.0
